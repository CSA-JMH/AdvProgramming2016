The Soul of Chyra v.1

To run the game right click and run or double click on the "finalproject.py" file in the folder.

Do NOT edit any of the other files in the folder. They are important components of the game.

Enjoy!