#Joshua Hinojosa
#Mr.Davis
#1/20/17
#Button Click Program


'''This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>'''

import pygame, sys
from pygame.locals import *


class Option:           #Creates class for hovering over the option buttons
    hovered = False

    def __init__(self, text, pos):
        self.text = text
        self.pos = pos
        self.set_rect()
        self.draw()

    def draw(self):
        self.set_rend()
        DISPLAYSURF.blit(self.rend, self.rect)

    def set_rend(self):
        self.rend = menu_font.render(self.text, True, self.get_color())

    def get_color(self):
        if self.hovered:            #if mouse is hovered then the color changes
            return (255, 255, 255)
        else:
            return (0, 0, 0)

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.rect.topleft = self.pos

pygame.init()
FPS = 60  # frames per second setting
fpsClock = pygame.time.Clock()
DISPLAYSURF = pygame.display.set_mode((600, 480))  # sets the window display size
menu_font = pygame.font.Font(None, 44)  # sets the font type and size for buttons
def main():
    # Setup colors
    #       R    G    B
    WHITE = (255, 255, 255)
    BLUE = (0, 0, 255)
    BLACK = (0, 0, 0)
    LIME = (0, 255, 0)

    KnightImg = pygame.image.load('knight50.png')  # defines the knight object
    NyanCatImg=pygame.image.load('Nyan-Cat.png')
    medievilBGImg = pygame.image.load('medieval_castle.jpg')  # defines background image
    soundObj = pygame.mixer.Sound('teleport_fx.wav')
    bgx = 0
    bgy = -10
    KnightImg = pygame.transform.scale(KnightImg, (40, 40))  # sets the image size
    NyanCatImg= pygame.transform.scale(NyanCatImg, (60, 60))
    pygame.init()
    kx = 362
    ky = 113
    nx=100
    ny=113
    save = False
    load = False
    while True:
        DISPLAYSURF.blit(medievilBGImg, (bgx, bgy))  #displays background
        buttonClicked=False
        mouseClicked=False
        saveBTN = [Option("SAVE", (260, 5))]
        quitBTN = [Option("QUIT", (40, 5))]
        loadBTN = [Option("LOAD", (148, 5))]
        for option1 in quitBTN:                 #check to see if the quit button is hovered by mouse
            if option1.rect.collidepoint(pygame.mouse.get_pos()):
                option1.hovered = True
            else:
                option1.hovered = False
            option1.draw()
        for option2 in saveBTN:                    #check to see if the save button is hovered by mouse
            if option2.rect.collidepoint(pygame.mouse.get_pos()):
                option2.hovered = True
            else:
                option2.hovered = False
            option2.draw()
        for option3 in loadBTN:                    #check to see if the load button is hovered by mouse
            if option3.rect.collidepoint(pygame.mouse.get_pos()):
                option3.hovered = True
            else:
                option3.hovered = False
            option3.draw()
        for event in pygame.event.get(): # event handling loop
            if event.type == QUIT or (event.type == KEYUP and event.key == K_ESCAPE):
                pygame.quit()
                sys.exit()
            elif event.type == MOUSEBUTTONDOWN:
                mouseClicked=True
            elif event.type == KEYDOWN:
                buttonClicked = True
            elif event.type == KEYDOWN:
                buttonClicked = False
        if save:       #writes the knight's last coordinats to a txt file
            outfile = open("location.txt", 'w')
            coordinates = str(kx) + ',' + str(ky) + '\n' + str(nx) + ','+ str(ny)
            outfile.write(coordinates)
            outfile.close()
            save=False

        elif load:   # reads the location txt file and puts the knight and nyan cat objects to last saved coordinates
            try:
                infile = open("location.txt", "r")
                line = infile.read().replace('\n'," ").replace(',', " ")
                data = []
                items = line.split()
                data.append(items)
                kx = int(data[0][0])
                ky = int(data[0][1])
                nx = int(data[0][2])
                ny = int(data[0][3])
                load=False
                infile.close()
            except FileNotFoundError:
                print("fil not found")
        # getting old knight positons
        oldkx=kx
        oldky=ky
        oldnx=nx
        oldny=ny
        if mouseClicked:
            if option1.hovered == True:
                quit()
            elif option2.hovered == True:
                save=True
            elif option3.hovered == True:
                load=True
        elif buttonClicked:       #checking to see if WASD or arrows keys have been pressed
            if event.key in (K_LEFT,K_j):  # LEFT
                kx, ky = oldkx - 10, oldky
                if kx <= 0:
                    kx = 0
            elif event.key in (K_RIGHT, K_l):  # RIGHT
                kx, ky = oldkx + 10, oldky
                if kx >= 550:
                    kx = 550
            elif event.key in (K_UP, K_i):  #UP
                kx, ky = oldkx, oldky - 10
                if ky <= 50:
                    ky = 50
            elif event.key in (K_DOWN, K_k):  #DOWN
                kx, ky = oldkx, oldky + 10
                if ky >= 440:
                    ky = 440
            elif event.key in (K_LEFT, K_a):  #Knight LEFT
                nx, ny = oldnx - 10, oldny
                if nx <= 0:
                    nx = 0
            elif event.key in (K_RIGHT, K_d):  #Knight RIGHT
                nx, ny = oldnx + 10, oldny
                if nx >= 550:
                    nx = 550
            elif event.key in (K_UP, K_w):  #Knight UP
                nx, ny = oldnx, oldny - 10
                if ny <= 50:
                    ny = 50
            elif event.key in (K_DOWN, K_s):  #Knight DOWN
                nx, ny = oldnx, oldny + 10
                if ny >= 440:
                    ny = 440
            soundObj.play()

        DISPLAYSURF.blit(KnightImg, (kx, ky))  # displays knight object to specific coordinates
        DISPLAYSURF.blit(NyanCatImg, (nx, ny))
        pygame.display.update()
        fpsClock.tick(FPS)
if __name__ == '__main__':      #runs the game main function
    main()