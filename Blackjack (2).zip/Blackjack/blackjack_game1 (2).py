#Joshua Hinojosa
#Mr. Davis
#Adv. Comp. Programming
#11/4/16
#v1.0
'''This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.'''

from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import random, tkinter

def about_prog():
    messagebox.showinfo("About", """Blackjack
    Version 1.0
    A user-friendly program GUI for the basic game of blackjack""")

def numchips_check():
    if int(dchips.get())==0:
        messagebox.showinfo("You Win!", "YOU WIN! Dealer ran out of chips.")
        reset()
    elif int(pchips.get())==0:
        messagebox.showinfo("game Over!", "Dealer wins! You ran out of chips.")
        reset()
def pcheckscore():
    if int(p1cardscore.get()) == 21:
        npchips = int(pchips.get()) + int(pot.get())
        messagebox.showinfo("Blackjack!", "YOU WIN!")
        pchips.set(npchips)
        placebet_btn.config(state='normal')
        bet_entry.config(state='normal')
        numchips_check()
        p1cardscore.set('---')
        p2cardscore.set('---')
        pcardinv.set("[ ]")
        dcardinv.set("[ ]")
        pot.set("")
def dcheckscore():
    if int(p2cardscore.get())==21:
        ndchips = int(dchips.get()) + int(pot.get())
        messagebox.showinfo("Blackjack!", "Dealer Wins!")
        dchips.set(ndchips)
        placebet_btn.config(state='normal')
        bet_entry.config(state='normal')
        pot.set("")
        numchips_check()
def reset():    #resets all of the components of the game
    p1cardscore.set('---')
    p2cardscore.set('---')
    pot.set('---')
    pchips.set('---')
    dchips.set('---')
    pcardinv.set("[ ]")
    dcardinv.set("[ ]")
    bet_entry.delete(0, END)
    start_btn.config(state='normal')
    hit_btn.config(state='disabled')
    pass_btn.config(state='disabled')
    placebet_btn.config(state='disabled')
    bet_entry.config(state='disabled')
def start():
    placebet_btn.config(state='normal')
    bet_entry.config(state='normal')
    start_btn.config(state='disabled')
    pchips.set("750")
    dchips.set("750")

def place_bet():        #function for placing your bet
    try:
        if int(bet.get())>int(pchips.get()):            #checks to see if the user enters anything other than a number or a number less than 1
            bet_entry.delete(0, END)
            messagebox.showinfo("Error!", "You can ONLY bet up to the number of chips you have!")
        elif int(bet.get())<1:
            bet_entry.delete(0, END)
            messagebox.showinfo("Error!", "You have to bet a number greater than 0!")

        else:
            placebet_btn.config(state='disabled')
            bet_entry.config(state='disabled')
            plyrchips=int(pchips.get())- int(bet.get())
            if int(bet.get())> int(dchips.get()):         #if you bet higher than the dealers chips than he puts all chips in
                dealrchips = int(dchips.get()) - int(dchips.get())
                winpot=int(dchips.get())+int(bet.get())
                pchips.set(plyrchips)
                dchips.set(dealrchips)
                pot.set(winpot)
                start_turn()
            else:
                dealrchips=int(dchips.get())- int(bet.get())
                pchips.set(plyrchips)
                dchips.set(dealrchips)
                winpot=2*int(bet.get())
                pot.set(winpot)
                start_turn()
    except ValueError:
        messagebox.showinfo("Error", "Must be a number!")
def start_turn():
    global carddeck, cards, cardinv
    cardinv = []
    hit_btn.config(state='normal')
    pass_btn.config(state='normal')
    cards = {'1♦': 1, '1♣': 1, '1♥': 1, '1♠': 1, '2♦': 2, '2♣': 2, '2♥': 2, '2♠': 2, '3♦': 3, '3♣': 3, '3♥': 3, '3♠': 3,
             '4♦': 4, '4♣': 4, '4♥': 4, '4♠': 4, '5♦': 5, '5♣': 5, '5♥': 5, '5♠': 5,
             '6♦': 6, '6♣': 6, '6♥': 6, '6♠': 6, '7♦': 7, '7♣': 7, '7♥': 7, '7♠': 7, '8♦': 8, '8♣': 8, '8♥': 8, '8♠': 8,
             '9♦': 9, '9♣': 9, '9♥': 9, '9♠': 9, '10♦': 10, '10♣': 10, '10♥': 10, '10♠': 10
        , 'J♦': 10, 'J♣': 10, 'J♥': 10, 'J♠': 10, 'Q♦': 10, 'Q♣': 10, 'Q♥': 10, 'Q♠': 10, 'K♦': 10, 'K♣': 10, 'K♥': 10,
             'K♠': 10}              #gives all of the cards score values

    carddeck = ['1♦', '1♣', '1♥', '1♠', '2♦', '2♣', '2♥', '2♠', '3♦', '3♣', '3♥', '3♠', '4♦', '4♣', '4♥', '4♠', '5♦',
                '5♣', '5♥', '5♠',
                '6♦', '6♣', '6♥', '6♠', '7♦', '7♣', '7♥', '7♠', '8♦', '8♣', '8♥', '8♠', '9♦', '9♣', '9♥', '9♠', '10♦',
                '10♣', '10♥', '10♠', 'J♦', 'J♣',
                'J♥', 'J♠', 'Q♦', 'Q♣', 'Q♥', 'Q♠', 'K♦', 'K♣', 'K♥', 'K♠', 'A♦', 'A♣', 'A♥', 'A♠']
            #creates the 52 card deck to choose cards from

    prandcard1 = random.choice(carddeck)
    carddeck.remove(prandcard1)
    prandcard2 = random.choice(carddeck)
    carddeck.remove(prandcard2)
    if prandcard2 == 'A♦' or prandcard2 == 'A♣' or prandcard2 == 'A♥' or prandcard2 == 'A♠':    #determines if the ace is worth 1 or 11 depending on other card
        if cards[prandcard1] <= 10:
            cards['A♦'] = 11
            cards['A♣'] = 11
            cards['A♥'] = 11
            cards['A♠'] = 11
        else:
            cards['A♦'] = 1
            cards['A♣'] = 1
            cards['A♥'] = 1
            cards['A♠'] = 1
    elif prandcard1 == 'A♦' or prandcard1 == 'A♣' or prandcard1 == 'A♥' or prandcard1 == 'A♠':
        if cards[prandcard2] <= 10:
            cards['A♦'] = 11
            cards['A♣'] = 11
            cards['A♥'] = 11
            cards['A♠'] = 11
        else:
            cards['A♦'] = 1
            cards['A♣'] = 1
            cards['A♥'] = 1
            cards['A♠'] = 1

    else:
        cards['A♦'] = 1
        cards['A♣'] = 1
        cards['A♥'] = 1
        cards['A♠'] = 1

    pnscore = cards[prandcard1] + cards[prandcard2]
    cardinv.append(prandcard1)
    cardinv.append(prandcard2)
    p1cardscore.set(str(pnscore))
    pcardinv.set(str(cardinv))
    pcheckscore()

def hit():
    global carddeck, cards, cardinv
    pcardrand=random.choice(carddeck)
    if pcardrand=='A♦' or pcardrand=='A♣' or pcardrand=='A♥' or pcardrand=='A♠':
        if int(p1cardscore.get()) <= 10:
            cards['A♦'] = 11
            cards['A♣'] = 11
            cards['A♥'] = 11
            cards['A♠'] = 11
        else:
            cards['A♦'] = 1
            cards['A♣'] = 1
            cards['A♥'] = 1
            cards['A♠'] = 1

    else:
        cards['A♦'] = 1
        cards['A♣'] = 1
        cards['A♥'] = 1
        cards['A♠'] = 1

    p1score=int(p1cardscore.get())+cards[pcardrand]
    cardinv.append(pcardrand)
    pcardinv.set(str(cardinv))
    p1cardscore.set(str(p1score))
    if int(p1cardscore.get())>21:       # if you get a card score over 21 when hitting, the dealer wins
        messagebox.showinfo("Bust!", "Dealer wins!")
        ndchips = int(dchips.get()) + int(pot.get())
        dchips.set(ndchips)
        placebet_btn.config(state='normal')
        bet_entry.config(state='normal')
        numchips_check()
        p1cardscore.set('---')
        p2cardscore.set('---')
        pcardinv.set("[ ]")
        dcardinv.set("[ ]")
        pot.set("")

def stay():                 #stops the players turn and is the dealer's turn
    global carddeck,cards
    pass_btn.config(state='disabled')
    dealerinv=[]
    hit_btn.config(state="disabled")
    dealerrandcard1=random.choice(carddeck)
    dealerrandcard2=random.choice(carddeck)
    if dealerrandcard2=='A♦' or dealerrandcard2=='A♣' or dealerrandcard2=='A♥' or dealerrandcard2=='A♠':
        if cards[dealerrandcard1]<=10:
            cards['A♦']=11
            cards['A♣']=11
            cards['A♥']=11
            cards['A♠']=11
        else:
            cards['A♦']=1
            cards['A♣']=1
            cards['A♥']=1
            cards['A♠']=1
    elif dealerrandcard1=='A♦' or dealerrandcard1=='A♣' or dealerrandcard1=='A♥' or dealerrandcard1=='A♠':
        if cards[dealerrandcard2]<=10:
            cards['A♦']=11
            cards['A♣']=11
            cards['A♥']=11
            cards['A♠']=11
        else:
            cards['A♦']=1
            cards['A♣']=1
            cards['A♥']=1
            cards['A♠']=1

    else:
        cards['A♦'] = 1
        cards['A♣'] = 1
        cards['A♥'] = 1
        cards['A♠'] = 1
    dnscore = cards[dealerrandcard1] + cards[dealerrandcard2]
    dealerinv.append(dealerrandcard1)
    dealerinv.append(dealerrandcard2)
    dcardinv.set(str(dealerinv))
    p2cardscore.set(str(dnscore))
    dcheckscore()
    while int(p2cardscore.get())<17 and int(p2cardscore.get())!=17:      #if the AI card score is less than and not equal 17 than it will keep
        dcardrand = random.choice(carddeck)                              #drawing cards
        if dcardrand == 'A♦' or dcardrand == 'A♣' or dcardrand == 'A♥' or dcardrand == 'A♠':
            if int(p2cardscore.get()) <= 10:
                cards['A♦'] = 11
                cards['A♣'] = 11
                cards['A♥'] = 11
                cards['A♠'] = 11
            else:
                cards['A♦'] = 1
                cards['A♣'] = 1
                cards['A♥'] = 1
                cards['A♠'] = 1

        else:
            cards['A♦'] = 1
            cards['A♣'] = 1
            cards['A♥'] = 1
            cards['A♠'] = 1

        p2score = int(p2cardscore.get()) + cards[dcardrand]
        dealerinv.append(dcardrand)
        dcardinv.set(str(dealerinv))
        p2cardscore.set(str(p2score))
    if int(p2cardscore.get()) > 21:             #if the dealer gets a card score over 21 when hitting, the player wins
        placebet_btn.config(state='normal')
        bet_entry.config(state='normal')
        messagebox.showinfo("You Win!", "Dealer busted!")
        npchips=int(pchips.get())+int(pot.get())
        pchips.set(npchips)
        numchips_check()
        p1cardscore.set('---')
        p2cardscore.set('---')
        pcardinv.set("[ ]")
        dcardinv.set("[ ]")
        pot.set("")
    else:
        if int(p1cardscore.get())>int(p2cardscore.get()):   # if the player has a higher card score when dealer stops drawing cards than the player wins
            npchips = int(pchips.get()) + int(pot.get())
            pchips.set(npchips)
            placebet_btn.config(state='normal')
            bet_entry.config(state='normal')
            messagebox.showinfo("", "You Win!")
            numchips_check()
            p1cardscore.set('---')
            p2cardscore.set('---')
            pcardinv.set("[ ]")
            dcardinv.set("[ ]")
            pot.set("")
        elif int(p1cardscore.get())<int(p2cardscore.get()):     # if the dealer has a higher card score when dealer stops drawing cards than the dealer wins
            ndchips = int(dchips.get()) + int(pot.get())
            dchips.set(ndchips)
            placebet_btn.config(state='normal')
            bet_entry.config(state='normal')
            messagebox.showinfo("", "Dealer Wins!")
            numchips_check()
            p1cardscore.set('---')
            p2cardscore.set('---')
            pcardinv.set("[ ]")
            dcardinv.set("[ ]")
            pot.set("")
        elif int(p1cardscore.get())==int(p2cardscore.get()):      #if the player and the dealer have the same card score after the dealer stops drawing cards then                                      #the dealer wins because dealer wins all ties
            ndchips = int(dchips.get()) + int(pot.get())
            dchips.set(ndchips)
            placebet_btn.config(state='normal')
            bet_entry.config(state='normal')
            messagebox.showinfo("", "Dealer Wins!")
            numchips_check()
            p1cardscore.set('---')
            p2cardscore.set('---')
            pcardinv.set("[ ]")
            dcardinv.set("[ ]")
            pot.set("")
root=Tk()
root.minsize(175, 175) #sets the minimum size the window can be shrinked
root.maxsize(500,500) #sets the maximum size the window can expand
root.title("Blackjack")
root.option_add('*tearOff', FALSE)  #removes the default dashes of the submenu
topMenu = Menu()
#creates menu and submenus (File and Help)
root.config(menu = topMenu)
subMenu= Menu(topMenu)
topMenu.add_cascade(label = "File", menu = subMenu)
subMenu.add_command(label="Exit", command=root.quit)
root.iconbitmap(default='blackjack.ico')
helpMenu = Menu(topMenu)
topMenu.add_cascade(label = "Help", menu = helpMenu)
helpMenu.add_command(label="About", command=about_prog)

mainframe = tkinter.Frame(root,bg='green', width=300, height=300)  #creates the mainframe and size of window
mainframe.grid(column=0, row=0, sticky=(N,S,E,W))
mainframe.columnconfigure(0, weight=1)
mainframe.rowconfigure(0, weight=1)

#Creates frame and content within the mainframe
content = tkinter.Frame(root, bg='green') #creates frame where the content of GUI will be shown
content.grid(column=0, row=0, sticky=(N,S,E,W))
root.grid_columnconfigure(0, weight=1)
root.grid_rowconfigure(0,weight=1)
content.grid_columnconfigure(1, weight=1)
content.grid_rowconfigure(1, weight=1)
content.grid_columnconfigure(0, weight=1)
content.grid_rowconfigure(0, weight=1)
content.grid_columnconfigure(2, weight=1)
content.grid_rowconfigure(2, weight=1)
content.grid_rowconfigure(3, weight=1)
content.grid_rowconfigure(4, weight=1)
content.grid_rowconfigure(5, weight=1)
content.grid_rowconfigure(6, weight=1)
content.grid_rowconfigure(7, weight=1)
content.grid_rowconfigure(8, weight=1)
content.grid_rowconfigure(9, weight=1)
content.grid_rowconfigure(10, weight=1)

####Variables
p1cardscore=StringVar()
p2cardscore=StringVar()
pcardinv=StringVar()
dcardinv=StringVar()
bet=StringVar()
pchips=StringVar()
dchips=StringVar()
pot=StringVar()

####Labels
bet_amountlbl=Label(content, bg='green',text="Bet Amount" )
bet_amountlbl.grid(column=0,row=0, padx=2, pady=2, sticky=(N,E))
cardscore_lbl=Label(content, bg='green',text="Card Scores")
cardscore_lbl.grid(column=0,row=7, padx=2, pady=2, sticky=(N,E))
p1cardscore_lbl=Label(content,bg='green', text="Player 1: ")
p1cardscore_lbl.grid(column=0,row=8, padx=2, pady=2, sticky=(N,E))
p1showcardscore_lbl=Label(content, bg='green', textvariable=p1cardscore)
p1showcardscore_lbl.grid(column=1,row=8, padx=2, pady=2, sticky=(N,W))
p2cardscore_lbl=Label(content,bg='green', text="Dealer: ")
p2cardscore_lbl.grid(column=0,row=9, padx=2, pady=2, sticky=(N,E))
p2showcardscore_lbl=Label(content, bg='green', textvariable=p2cardscore)
p2showcardscore_lbl.grid(column=1,row=9, padx=2, pady=2, sticky=(N,W))
pcardinv_lbl=Label(content, bg='green',text="Player Card Inventory:")
pcardinv_lbl.grid(column=0,row=10, padx=2, pady=2, sticky=(N,E))
pshowcardinv=Label(content, bg='green', textvariable=pcardinv)
pshowcardinv.grid(column=1,row=10, padx=2, pady=2, sticky=(N,W))
dcardinv_lbl=Label(content, bg='green',text="Dealer Card Inventory:")
dcardinv_lbl.grid(column=0,row=11, padx=2, pady=2, sticky=(N,E))
dshowcardinv=Label(content, bg='green', textvariable=dcardinv)
dshowcardinv.grid(column=1,row=11, padx=2, pady=2, sticky=(N,W))
pchips_amountlbl=Label(content, bg='green',text="Player Chips:")
pchips_amountlbl.grid(column=0,row=5, padx=2, pady=2, sticky=(N,E))
showpchips_lbl=Label(content,bg='green', textvariable=pchips)
showpchips_lbl.grid(column=1,row=5, padx=2, pady=2, sticky=(N,W))
dchips_amountlbl=Label(content,bg='green', text="Dealer Chips:")
dchips_amountlbl.grid(column=0,row=6, padx=2, pady=2, sticky=(N,E))
showdchips_lbl=Label(content,bg='green', textvariable=dchips)
showdchips_lbl.grid(column=1,row=6, padx=2, pady=2, sticky=(N,W))
winpot_lbl=Label(content,bg='green', text="Pot:")
winpot_lbl.grid(column=0,row=2,padx=2, pady=2, sticky=(N,E))
winpotshow_lbl=Label(content,bg='green', textvariable=pot)
winpotshow_lbl.grid(column=1,row=2,padx=2, pady=2, sticky=(N,W))

####Buttons
start_btn=Button(content, width=10,text="Start Game", command=start)
start_btn.grid(column=0, row=3, padx=2, pady=2, sticky=N)
hit_btn=Button(content, width=6,state='disabled', text="Hit", command=hit)
hit_btn.grid(column=3, row=1, padx=2, pady=2, sticky=(N))
pass_btn=Button(content, width=6,state='disabled', text="Pass", command=stay)
pass_btn.grid(column=3, row=2, padx=2, pady=2, sticky=(N))
placebet_btn=Button(content,state='disabled', text='Place Bet', command=place_bet)
placebet_btn.grid(column=0, row=1, padx=2, pady=2, sticky=(N))
reset_btn=Button(content, text='New Game', command=reset)
reset_btn.grid(column=3, row=12, padx=2, pady=2, sticky=(S,W))

###Entry
bet_entry=Entry(content, width=5,state='disabled', textvariable=bet)
bet_entry.grid(column=1, row=0, padx=2, pady=2, sticky=(N))

p1cardscore.set('---')
p2cardscore.set('---')
pot.set('---')
pchips.set('---')
dchips.set('---')
pcardinv.set("[ ]")
dcardinv.set("[ ]")
bet.set("")

root.mainloop()